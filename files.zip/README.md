# Fat Loss Tracker

**Cut through the noise. See your real fat loss — not water weight.**

A single-file, zero-dependency calorie calculator that gives you an honest, math-based estimate of fat burned based on your MyFitnessPal logs and step count.

## Why this exists

The scale is a liar. Water retention, inflammation, sodium, hormonal shifts — all of it can mask 3–5 lbs of *real fat loss*. This tool shows you the number the scale can't: your actual caloric deficit, and what that mathematically means for fat burned.

## What it does

- Takes your **weight, height, age, and sex** to calculate your BMR using the Mifflin-St Jeor equation
- Lets you paste in up to 30 days of:
  - **Calories eaten** from MyFitnessPal
  - **Step count** from your watch/Fitbit/Apple Watch
  - **Exercise calories burned** from your MFP exercise log
- Calculates your **real TDEE** (Total Daily Energy Expenditure) including step-based NEAT
- Shows you **fat burned** projected over 7 days or 1 month
- Gives you a **day-by-day projection bar chart**

## The math

| Component | Formula |
|---|---|
| BMR | Mifflin-St Jeor equation |
| NEAT (steps) | steps × (bodyweight_lbs / 150) × 0.04 kcal |
| Total burn | BMR × 1.2 (sedentary base) + NEAT + exercise |
| Fat burned | total deficit ÷ 3,500 kcal per lb |

> **Why 3,500?** One pound of body fat stores approximately 3,500 kcal of energy. This is a well-established approximation used in clinical and research settings.

> **Why sedentary × 1.2 as the base?** Steps are counted separately as NEAT, so we use the lowest activity multiplier for BMR to avoid double-counting.

## How to use

1. Clone or download this repo
2. Open `index.html` in any browser — no server, no install, no account
3. Fill in your stats
4. Paste your last 7 days from MFP + your watch
5. Hit Calculate

## Accuracy notes

- **NEAT estimation** (calories burned from steps) is weight-adjusted but still an approximation. Walking speed and stride length affect real burn.
- **Exercise calories** from MFP are often *overestimated* by 20–30%. For more accurate results, subtract 20% from MFP's exercise estimates.
- **BMR formulas** have ±5–10% individual variation.
- **Don't panic about the scale** in the first 2–3 weeks. Water weight shifts of 3–5 lbs are normal and have nothing to do with fat.

## The key insight

Your body follows thermodynamics. If your deficit is real, fat loss is happening — even when the scale says otherwise. This tool shows you the thermodynamic truth so you don't give up when the scale is being noisy.

## License

MIT
